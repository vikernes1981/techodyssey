import { useEffect, useRef, useState } from "react";
import Header from "./Header";

const QA = [
  { user: "whoami ", assistant: "Iordanis Tsitsirikos" },
  { user: "role ", assistant: "Backend Developer & Linux Enthusiast" },
  { user: "about ", assistant: "I build secure, efficient, and tested full-stack web applications." },
  { user: "contact ", assistant: "joe_tsitsirikos@mail.techodyssey.org" },
  { user: "github ", assistant: "https://github.com/vikernes1981" },
  //{ user: "linkedin ", assistant: "https://linkedin.com/in/your-linkedin" },
  { user: "project ", assistant: "Try Terminal Chat by clicking below." }
];

export default function HomePage() {
  const [history, setHistory] = useState([]);
  const [step, setStep] = useState(0);
  const [userPrompt, setUserPrompt] = useState("");
  const [assistantTyping, setAssistantTyping] = useState(false);
  const [assistantPrompt, setAssistantPrompt] = useState("");
  const [done, setDone] = useState(false);
  const containerRef = useRef(null);

  // Typing effect controller
  useEffect(() => {
    let timer;
    if (step < QA.length) {
      if (!assistantTyping && userPrompt.length < QA[step].user.length) {
        // Type user command at prompt (below box)
        timer = setTimeout(() => {
          setUserPrompt(QA[step].user.slice(0, userPrompt.length + 1));
        }, 50);
      } else if (!assistantTyping && userPrompt.length === QA[step].user.length) {
        // Move user command to history, start typing assistant inside box
        setHistory((prev) => [
          ...prev,
          { type: "user", text: QA[step].user }
        ]);
        setUserPrompt("");
        setAssistantTyping(true);
      } else if (assistantTyping && assistantPrompt.length < QA[step].assistant.length) {
        // Type assistant inside box
        timer = setTimeout(() => {
          setAssistantPrompt(QA[step].assistant.slice(0, assistantPrompt.length + 1));
        }, 50);
      } else if (assistantTyping && assistantPrompt.length === QA[step].assistant.length) {
        // Move assistant to history, advance to next
        setHistory((prev) => [
          ...prev,
          { type: "assistant", text: QA[step].assistant }
        ]);
        setAssistantPrompt("");
        setAssistantTyping(false);
        setStep((s) => s + 1);
      }
    } else {
      setDone(true);
      setUserPrompt("");
      setAssistantPrompt("");
    }
    return () => clearTimeout(timer);
    // eslint-disable-next-line
  }, [step, userPrompt, assistantTyping, assistantPrompt]);

  // Auto scroll to bottom on new output
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [history, assistantPrompt]);

  return (
    <div className="h-screen w-full bg-black flex flex-col">
      <Header />
      <div className="flex-1 flex flex-col items-center justify-center">
        <div className="w-full max-w-3xl mx-auto mt-8 flex flex-col justify-end">
          {/* Terminal box */}
          <div
            ref={containerRef}
            className="flex-1 px-2 py-4 overflow-y-auto flex flex-col justify-end text-green-200 font-mono text-lg border border-green-400 rounded-xl bg-black shadow-lg"
            style={{
              height: "420px",
              minHeight: 260,
              boxShadow: "0 0 24px #0f0a",
              borderRadius: "18px 18px 12px 12px"
            }}
          >
            {history.map((msg, i) => (
              <div key={i} className="flex flex-col mb-1">
                {msg.type === "user" ? (
                  <div className="flex items-center">
                    <span className="text-green-400 mr-2">$</span>
                    <span className="font-bold text-green-300">{msg.text}</span>
                  </div>
                ) : (
                  <div className="flex items-start">
                    <span className="text-green-400 mr-2">$</span>
                    <span className="text-green-50" style={{ whiteSpace: "pre-wrap" }}>
                      {
                        msg.text.includes("https://")
                          ? msg.text.split(" ").map((word, idx) =>
                              word.startsWith("https://") ? (
                                <a
                                  key={idx}
                                  href={word}
                                  className="underline hover:text-green-200"
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  {word}
                                </a>
                              ) : (
                                <span key={idx}> {word} </span>
                              )
                            )
                          : msg.text
                      }
                    </span>
                  </div>
                )}
              </div>
            ))}

            {/* Assistant is typing (inside box) */}
            {assistantTyping && assistantPrompt && (
              <div className="flex items-center">
                <span className="text-green-400 mr-2">$</span>
                <span className="text-green-50">{assistantPrompt}
                  <span className="animate-pulse text-green-400">|</span>
                </span>
              </div>
            )}
          </div>
          {/* Horizontal green line */}
          <div
            className="w-full border-t border-green-400"
            style={{
              boxShadow: "0 0 10px #39ff14"
            }}
          />
          {/* Terminal prompt below the line */}
          <div className="w-full px-5 pb-3 pt-2 flex items-center bg-black rounded-b-xl">
            <span className="text-green-400 font-mono text-xl select-none">$</span>
            {!done && (
              <span className="ml-2 font-bold text-green-300">
                {userPrompt}
                <span className="animate-pulse text-green-400">|</span>
              </span>
            )}
            {done && (
              <>
                <a
                  href="/terminal-chat"
                  className="ml-4 bg-black border border-green-400 rounded px-4 py-2 font-bold text-green-200 hover:bg-green-500 hover:text-green-50 transition"
                >
                  Terminal Chat
                </a>
                <span className="ml-4 text-green-500 text-sm">[No input: demo mode]</span>
              </>
            )}
          </div>
        </div>
      </div>
      <footer className="w-full text-center text-green-500 text-xs py-2 mt-6 select-none">
        © 2025 TechOdyssey. All rights reserved.
      </footer>
    </div>
  );
}
