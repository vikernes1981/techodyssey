SETUP
--------

git clone git@github.com:vikernes1981/FullStackBlog.git
cd FullStackBlog/backend
npm i
npm run dev
cd ../frontend
npm i
npm run dev
Navigate to http://localhost:5173/

